/* eslint-disable no-unused-vars */
class RepliesRepository {
  async addReplies(replies) {
    throw new Error('REPLIES_REPOSITORY.METHOD_NOT_IMPLEMENTED')
  }
  async deleteReplies(replies) {
    throw new Error('REPLIES_REPOSITORY.METHOD_NOT_IMPLEMENTED')
  }
  async checkRepliesIsExist(replies) {
    throw new Error('REPLIES_REPOSITORY.METHOD_NOT_IMPLEMENTED')
  }
  async checkRepliesOwner(replies) {
    throw new Error('REPLIES_REPOSITORY.METHOD_NOT_IMPLEMENTED')
  }
  async getRepliesInComment(replies) {
    throw new Error('REPLIES_REPOSITORY.METHOD_NOT_IMPLEMENTED')
  }
}

module.exports = RepliesRepository
